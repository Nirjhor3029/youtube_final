@extends('layouts.admin')

@push('css')

@endpush

@section('content')

@endsection

@push('scripts')

@endpush
