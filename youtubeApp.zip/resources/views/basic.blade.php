@extends('layouts.app')

@push('css')

@endpush

@section('content')

@endsection

@push('scripts')

@endpush
