<div id="thanks" class="modal fade">
  <div class="modal-dialog modal-login">
    <div class="modal-content">
      <div class="modal-body text-center">
        <img src="{{asset('img/ayojok-logo-transparent.png')}}" alt="" style="width:13rem;">
        <p>Thank you for submitting your phone number. Ayojok team will contact with you very soon.</p>
      </div>
    </div>
  </div>
</div>
<!--Thank you Modal HTML-->
