<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 2/20/2019
 * Time: 4:59 PM
 */
?>

@extends('layouts.admin')

@push('css')

@endpush

@section('content')

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Product Categories
            </h1>
        </section>

        <section class="maincontent">

            <div class="col-md-12" style="margin-top:2rem;">

                <div class="box box-primary">
                    <div class="box-body ">

                        <div class="list-group">
                            <?php $i = 0; ?>
                            @foreach ($datas as $data)

                                <div class="row">
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-4">
                                        <a href="{{route('product.categories',[$data->id])}}" class="list-group-item list-group-item-action " style="margin-top: 3px">
                                            <div class="row">
                                                <div class="col-sm-10">{{$data->name}}</div>
                                                <div class="col-sm-1">
                                                    <span class="badge badge-success badge-pill">{{$badges[$i]}}</span>
                                                </div>
                                                <div class="col-sm-1">
                                                    <span class="glyphicon glyphicon-forward"></span>
                                                </div>

                                            </div>
                                        </a>
                                    </div>
                                </div>

                                    <?php $i++; ?>

                            @endforeach


                        </div>



                    </div><!-- /.box-body -->
                </div><!-- /.box -->

            </div>



        </section><!-- /.content -->
    </div>

@endsection

@push('scripts')
<script>
    $(function () {
        $('#example1').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : true,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false
        })
    })

    function deleteAlert(){
        //alert("alert");
        var x = confirm("Are you sure you want to delete this data ? ");
        return x;
    }
</script>
@endpush


