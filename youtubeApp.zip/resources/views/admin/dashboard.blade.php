@extends('layouts.admin')

@push('css')
@endpush
@section('content')
    <div style="text-align: center">
        <div>
            <iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vQ-1hI-RBDgGwJkXKpeyJYU329YSDt9eboh1SRdRJ3G2MQXFwWUeNpLfbNbvPgBQcIbT1Y1VmQs_E-y/pubhtml?gid=0&amp;single=true&amp;widget=true&amp;headers=false"></iframe>
        </div>
        <div>
            <iframe width="600" height="371" seamless frameborder="0" scrolling="no"
                    src="https://docs.google.com/spreadsheets/d/e/2PACX-1vQ-1hI-RBDgGwJkXKpeyJYU329YSDt9eboh1SRdRJ3G2MQXFwWUeNpLfbNbvPgBQcIbT1Y1VmQs_E-y/pubchart?oid=771502881&amp;format=interactive"></iframe>
        </div>
        <div>
            <iframe width="600" height="371" seamless frameborder="0" scrolling="no"
                    src="https://docs.google.com/spreadsheets/d/e/2PACX-1vQ-1hI-RBDgGwJkXKpeyJYU329YSDt9eboh1SRdRJ3G2MQXFwWUeNpLfbNbvPgBQcIbT1Y1VmQs_E-y/pubchart?oid=1081749502&amp;format=interactive"></iframe>
        </div>
        <div>
            <iframe width="600" height="371" seamless frameborder="0" scrolling="no"
                    src="https://docs.google.com/spreadsheets/d/e/2PACX-1vQ-1hI-RBDgGwJkXKpeyJYU329YSDt9eboh1SRdRJ3G2MQXFwWUeNpLfbNbvPgBQcIbT1Y1VmQs_E-y/pubchart?oid=1032529278&amp;format=interactive"></iframe>
        </div>

    </div>
@endsection
@push('scripts')
@endpush