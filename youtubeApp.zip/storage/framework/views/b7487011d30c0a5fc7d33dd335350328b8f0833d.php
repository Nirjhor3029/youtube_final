<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 3/13/2019
 * Time: 11:19 AM
 */
?>



<?php $__env->startPush('css'); ?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>

    img{
        width: 100px;
        height: 100px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">



        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                App User Token List
            </h1>
        </section>

        <section class="maincontent">
            <div class="col-md-12" style="margin-top:2rem;">

                <div class="box box-danger">

                    <div class="box-body table-responsive">
                        <table id="table" class="table table-bordered">
                            <a href="<?php echo e(route('addAppUsersToken')); ?>" class="btn btn-primary">Add New</a>
                            <thead>
                            <tr>
                                <th> ID</th>
                                <th>App User Token</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $vdo_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_vdo_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($v_vdo_category->id); ?></td>
                                    <td><?php echo e($v_vdo_category->app_token); ?></td>

                                    <td>
                                        
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <a href="<?php echo e(route('deleteAppUsersToken',$v_vdo_category->id)); ?>"><i class="fa fa-remove" style="font-size:30px;color:red"></i></a>
                                            </div>
                                            <div class="col-sm-2">
                                                <a href="<?php echo e(route('editAppUsersToken',$v_vdo_category->id)); ?>"><i class="fa fa-edit" style="font-size:30px;color:green"></i></a>
                                            </div>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

            </div>

        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>