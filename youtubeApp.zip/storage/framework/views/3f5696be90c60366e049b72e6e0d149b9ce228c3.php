
<!-- Incorrect Email Modal -->
    <div class="modal fade" id="myModal_2" role="dialog">
        <div class="modal-dialog modal-login">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Warning !</h4>
                </div>
                <div class="modal-body text-center">
                    <p>Email already exist use different login method !! .</p>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Login Modal HTML -->
<div id="myModal" class="modal fade">
  <div class="modal-dialog modal-login">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Sign In To Ayojok</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo e(csrf_field()); ?>


          <div class="form-group">

            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-user"></i></span>
              <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus >

              <?php if($errors->has('email')): ?>
                  <span class="invalid-feedback" id="error" onclick="vanishErrorMessage(this)">
                      <strong><?php echo e($errors->first('email')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
          </div>

          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-lock"></i></span>
              <input input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

              <?php if($errors->has('password')): ?>
                  <span class="invalid-feedback" onclick="vanishErrorMessage(this)">
                      <strong><?php echo e($errors->first('password')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="form-group row">
              <div class="col-md-6 offset-md-4">
                  <div class="checkbox">
                      <label>
                          <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

                      </label>
                  </div>
              </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block btn-lg"><?php echo e(__('Sign In')); ?></button>
            <button type="submit" class="btn btn-primary btn-block btn-lg" data-dismiss="modal" data-toggle="modal" href="#registerModal">Register Now</button>
          </div>
          <div class="text-center">
            <a href="<?php echo e(url('login/google')); ?>" class="btn google"><i class="fa fa-google"></i> Google</a>
            <a href="<?php echo e(url('login/facebook')); ?>" class="btn fb fa-fw"><i class="fa fa-facebook"></i> Facebook</a>
          </div>

          <div class="text-center mt-2">
            <p style="font-size:0.8rem; color:#f47f20;">Don't want to Register?</p>
            <button type="submit" class="btn btn-primary btn-block btn-lg" data-dismiss="modal" data-toggle="modal" href="#levnum">Leave Your Number</button>
          </div>
        </form>
      </div>
      <div class="modal-footer"><p class="hint-text"><a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a></p></div>
    </div>
  </div>
</div>
<!--Login Modal HTML-->
<script>
    function vanishErrorMessage(ob){
        //alert("ok");
        ob.style.display = "none";
    }
</script>
