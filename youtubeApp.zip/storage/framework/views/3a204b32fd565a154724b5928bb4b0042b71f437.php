<?php
/**
 * Created by PhpStorm.
 * User: Sohel Rana
 * Date: 3/17/2019
 * Time: 12:37 AM
 */

?>




<?php $__env->startPush('css'); ?>
<style>
    img {
        width: 300px;
        height: 200px;
    }
</style>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Add New Video
            </h1>
        </section>

        <section class="maincontent">

            <div class="col-md-12" style="margin-top:2rem;">
                <div class="box box-primary">
                    <div class="box-body" style="margin-top:2rem;">
                        <form action="<?php echo e(route('getVideoInfo')); ?>" method="post" class="form-horizontal"
                              enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="row form-group">
                                <div class="col-sm-2">
                                    <label for="vendor_name" class="control-label">Video Url: <span
                                                style="color:red;">*</span> </label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" placeholder="Enter Youtube Video Url"
                                           name="video_url" required>
                                </div>
                            </div>
                            <div>
                                <button class="btn btn-success pull-right" type="submit">Get Video Info</button>
                            </div>
                        </form>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

                <?php if(isset($videoInfo)): ?>

                    <div class="col-md-12" style="margin-top:2rem;">
                        <div class="box box-primary">
                            <div class="box-body" style="margin-top:2rem;">
                                <form action="<?php echo e(route('addVideoSubmit')); ?>" method="post" class="form-horizontal"
                                      enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Video ID: <span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="vendor_name"
                                                   placeholder="Enter Title" name="video_id" value="<?php echo e($videoId); ?>"
                                                   required>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Categoryt<span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="category" required>
                                                <option value="<?php echo e(null); ?>">Select Category</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                    </div>


                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Sub Categoryt<span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="sub_category" required>
                                                <option>Select Sub Category</option>
                                                <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->title); ?>( <?php echo e($sub_category->vdoCategory->title); ?> )</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Tags<span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <select class=" js-example-basic-multiple form-control" name="tags[]"
                                                    multiple="multiple" required>
                                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>


                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Video Url: <span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" placeholder="Enter Video Url"
                                                   name="video_url" value="<?php echo e($videoUrl); ?>" required>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Author Url: <span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" placeholder="Enter Author Url"
                                                   name="author_url" value="<?php echo e($videoInfo->author_url); ?>" required>
                                        </div>
                                    </div>


                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Author Name: <span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" placeholder="Enter Author Name"
                                                   name="author_name" value="<?php echo e($videoInfo->author_name); ?>" required>
                                        </div>
                                    </div>


                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Title <span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" placeholder="Enter Title"
                                                   name="title" value="<?php echo e($videoInfo->title); ?>" required>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Description <span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">

                                            <textarea class="form-control" name="description"
                                                      placeholder="Enter Video Description"></textarea>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Thumbnail url<span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" placeholder="Enter Descripton"
                                                   name="thumbnail_url" value="<?php echo e($videoInfo->thumbnail_url); ?>" required>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Thumbnail View<span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <img src="<?php echo e($videoInfo->thumbnail_url); ?>">
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col-sm-2">
                                            <label for="vendor_name" class="control-label">Video Length<span
                                                        style="color:red;">*</span> </label>
                                        </div>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" placeholder="Enter Descripton"
                                                   name="video_length" value="" required>
                                        </div>
                                    </div>


                                    <div>
                                        <button class="btn btn-primary pull-right" type="submit">Upload Video Info
                                        </button>
                                    </div>
                                </form>

                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
            </div>

            <?php endif; ?>


        </section>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<script>
    $(document).ready(function () {
        $('.js-example-basic-multiple').select2();
    });
</script>

<script>
    $(function () {
        $('#table').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': false,

        })
    })
</script>

<script>
    function previewprofileImage() {
        var $preview = $('#profile-preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)) {
                return alert(file.name + " is not an image");
            }
            var reader = new FileReader();

            $(reader).on("load", function () {
                $preview.append($("<img/>", {src: this.result}));
            });

            reader.readAsDataURL(file);

            $('#previous_image').hide();

        }
    }


    $('#profile_image').on("change", previewprofileImage);


    $('#menu_type_select,#event_type_select,#speciality_select,#bakery_speciality_select,#venue_area_select,#home_service_select').select2();


</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>