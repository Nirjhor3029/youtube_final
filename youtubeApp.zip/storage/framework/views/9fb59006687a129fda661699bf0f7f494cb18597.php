<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Order Details
      </h1>
    </section>

    <section class="maincontent">

      <div class="col-md-4" style="margin-top:2rem;">

        <div class="box box-danger">
          <div class="box-body" id="status">
            <div class="details">
              <label for="id" class="control-label col-md-4">Client ID:</label>
              <div class="col-md-8">
                <p><?php echo e($user->id); ?></p>
              </div>
              <label for="email" class="control-label col-md-4">Client Email:</label>
              <div class="col-md-8">
                <p><?php echo e($user->email); ?></p>
              </div>
              <label for="username" class="control-label col-md-4">Client Username:</label>
              <div class="col-md-8">
                <p><?php echo e($user->name); ?></p>
              </div>
              <label for="name" class="control-label col-md-4">Client Name:</label>
              <div class="col-md-8">
                <?php if(empty($user->fname) && empty($user->lname)): ?>
                  <p><?php echo "<span class='label label-warning'>Not Set Yet</span>"; ?></p>
                <?php else: ?>
                  <p><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></p>
                <?php endif; ?>
              </div>
              <label for="contact" class="control-label col-md-4">Client Contact:</label>
              <div class="col-md-8">
                <p><?php echo e($user->contact); ?></p>
              </div>
              <label for="address" class="control-label col-md-4">Client Address:</label>
              <div class="col-md-8">
                <p><?php echo isset($user->address) ? $user->address : "<span class='label label-warning'>Not Set Yet</span>"; ?></p>
              </div>
            </div>
          </div><!-- /.box-body -->
        </div><!-- /.box -->

      </div>

      
      <div class="col-md-4" style="margin-top:2rem;">
        <div class="box box-info">
          <div class="box-header">
            <strong>Client Summery</strong>
          </div>
          <div class="box-body">
            <div class="details row">
              <label for="name" class="control-label col-md-4">Total Order:</label>
              <div class="col-md-8">
                <?php
                  $totalOrder = App\Models\order::where('user_id',$user->id)->where('payment_type','>',0)->count();
                ?>
                <p><strong><?php echo e(isset($totalOrder) ? $totalOrder : 0); ?></strong> Service</p>
              </div>

              <label for="name" class="control-label col-md-4">Total Advance Paid:</label>
              <div class="col-md-8">
                <?php
                  $totaladvance = App\Models\order::where('user_id',$user->id)->where('payment_type','>',0)->sum('advance');
                ?>
                <p> <strong><?php echo e(isset($totaladvance) ? $totaladvance : 0); ?> BDT</strong> </p>
              </div>
              </div>
          </div>
        </div>
      </div>

      
      

      <div class="col-md-12" style="margin-top:2rem;">

        <div class="box box-danger">
          <div class="box-body table-responsive">
            <table id="table" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Order Date</th>
                  <th>Order Delivery Date </th>
                  <th>Service Name</th>
                  <th>Delivery Time</th>
                  <th>Advance</th>
                  <th>Total</th>
                  <th>Advance Payment Type</th>
                  <th>Invoice Id</th>
                  <th>Vendor Payment</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($data->id); ?></td>
                    <td><?php echo e($data->created_at->format('d M Y')); ?></td>
                    <td><?php echo e($data->order_date); ?></td>
                    <td><?php echo e(isset($data->product->title) ? $data->product->title : $data->vendor->title); ?></td>
                    <td><?php echo e($data->time); ?></td>
                    <td><?php echo e($data->advance); ?></td>
                    <td><?php echo e($data->total); ?></td>
                    <td>
                      <?php if($data->payment_type == 2): ?>
                        <?php echo e(_("Bkash")); ?>

                      <?php elseif($data->payment_type == 1): ?>
                        <?php echo e(_("Online Payments")); ?>

                      <?php elseif($data->payment_type == 0): ?>
                        <?php echo e(_("Advance Not Paid")); ?>

                      <?php endif; ?>
                    </td>
                    <td>
                      <?php echo Form::open(['method' => 'GET','route'=> ['invoice',$data->invoice_id],'style'=>'display:inline']); ?>

                      <?php echo Form::button('#'.$user->id.$data->invoice_id,['class'=> 'btn btn-xs', 'style' => 'font-size:1.5rem;color:#f47f20;background: none;','type' => 'submit','data-toggle'=>'tooltip', 'data-placement'=>'bottom', 'title'=>'Click, to see the invoice !']); ?>

                      <?php echo Form::close(); ?>

                    </td>
                    <td>
                      <?php if($data->is_paid == 0): ?>
                        <?php echo e(_("Not Paid Yet")); ?>

                      <?php else: ?>
                        <?php echo e(_("Paid")); ?>

                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($data->is_paid == 0): ?>
                        <?php echo Form::open(['method' => 'POST','route'=> ['manual-payment',$data->id],'style'=>'display:inline']); ?>

                        <?php echo Form::button('<span class="fa fa-sm fa-check" style="" aria-hidden="true"></span>',['class'=> 'btn btn-xs', 'style' => 'font-size:2rem;color:#f47f20;background: none;','type' => 'submit','data-toggle'=>'tooltip', 'data-placement'=>'left', 'title'=>'Click, if paid to vendor !']); ?>

                        <?php echo Form::close(); ?>

                      <?php endif; ?>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->

        </div>



    </section><!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>
  $(function () {
    $('#table').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : false
    })
  })



  </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>