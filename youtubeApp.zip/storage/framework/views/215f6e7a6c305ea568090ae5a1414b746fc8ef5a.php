

<!-- Register Modal HTML -->
 <div id="registerModal" class="modal fade">
   <div class="modal-dialog modal-login">
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title">Register To Ayojok</h4>
         <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       </div>
       <div class="modal-body">
         <form method="POST" action="<?php echo e(route('register')); ?>">
           <?php echo e(csrf_field()); ?>


           <div class="form-group">
             <div class="input-group">
               <span class="input-group-addon"><i class="fa fa-user"></i></span>
               <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="Your Username" required autofocus>

               <?php if($errors->has('name')): ?>
                   <span class="invalid-feedback" onclick="vanishErrorMessage(this)">
                       <strong><?php echo e($errors->first('name')); ?></strong>
                   </span>
               <?php endif; ?>
             </div>
           </div>
           <div class="form-group">
             <div class="input-group">
               <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
               <input id="useremail" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Your Email" required>

               <?php if($errors->has('email')): ?>
                   <span class="invalid-feedback" onclick="vanishErrorMessage(this)">
                       <strong><?php echo e($errors->first('email')); ?></strong>
                   </span>
               <?php endif; ?>
             </div>
           </div>
           <div class="form-group">
             <div class="input-group">
               <span class="input-group-addon"><i class="fa fa-phone"></i></span>
               <input id="usercontact" type="text" class="form-control<?php echo e($errors->has('contact') ? ' is-invalid' : ''); ?>" name="contact" value="<?php echo e(old('contact')); ?>" placeholder="Your Contact Number" required>

               <?php if($errors->has('email')): ?>
                   <span class="invalid-feedback" onclick="vanishErrorMessage(this)">
                       <strong><?php echo e($errors->first('email')); ?></strong>
                   </span>
               <?php endif; ?>
             </div>
           </div>
           <div class="form-group">
             <div class="input-group">
               <span class="input-group-addon"><i class="fa fa-lock"></i></span>
               <input id="userpassword" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>

               <?php if($errors->has('password')): ?>
                   <span class="invalid-feedback" onclick="vanishErrorMessage(this)">
                       <strong><?php echo e($errors->first('password')); ?></strong>
                   </span>
               <?php endif; ?>
             </div>
           </div>
           <div class="form-group">
             <div class="input-group">
               <span class="input-group-addon"><i class="fa fa-lock"></i></span>
               <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required>
             </div>
           </div>
           <div class="form-group">
             <button type="registerSubmit" class="btn btn-primary btn-block btn-lg"><?php echo e(__('Sign Up')); ?></button>
           </div>

         </form>
       </div>
       <div class="modal-footer"><p class="hint-text"><a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a></p></div>
     </div>
   </div>
 </div>
 <!--Register Modal HTML-->

<script>
    function vanishErrorMessage(ob){
        //alert("ok");
        ob.style.display = "none";
    }
</script>