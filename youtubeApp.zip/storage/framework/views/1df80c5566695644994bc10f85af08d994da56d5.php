<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({'gtm.start': new Date().getTime(), event: 'gtm.js'});
            var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-K2GSM38');
    </script>

    
    

    <title>Ayojok | One Stop Solution for your event</title>


    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Custom fonts for this theme -->
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic'
          rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,600,500,700,800,900' rel='stylesheet'
          type='text/css'>

    <!-- Plugin CSS -->
    <link href="<?php echo e(asset('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/owl-carousel/owl.theme.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/owl-carousel/owl.transitions.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/magnific-popup/magnific-popup.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/animate.css/animate.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendor/datetimepicker/css/bootstrap-datetimepicker.css')); ?>" rel="stylesheet" type="text/css">


    <!-- Styles -->
    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet" type="text/css">

    <link rel="icon" href="<?php echo e(asset('img/ayojok-logo-transparent.png')); ?>" type="image/x-icon">

    <?php echo $__env->yieldPushContent('css'); ?>


            <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131344123-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        /*extra*/
        gtag('set', {'user_id': 'USER_ID'}); // Set the user ID using signed-in user_id.
        ga('set', 'userId', 'USER_ID'); // Set the user ID using signed-in user_id.

        gtag('config', 'UA-131344123-1');
    </script>


</head>
<body>
<noscript>
    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K2GSM38" height="0" width="0"
            style="display:none;visibility:hidden"></iframe>
</noscript>
<div id="page-top">
    <?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('auth.register', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('extra.leavenum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('extra.thankyou', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Navigation -->
    <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
        <div class="container">

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                    aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
                Menu
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">

                <!-- Top Menu -updated -->
                <ul class="nav navbar-nav ">

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>"> <img class="logo_as_home"
                                                                                  src="<?php echo e(asset('img/ayojok_v2.png')); ?>">
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('how-it-works')); ?>">How it Works</a>
                    </li>
                    <li class="nav-item dropdown">
                        
                        <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
                        <ul class="megamenu dropdown-menu scrollable-menu " id="dropdown-menu"
                            aria-labelledby="navbarDropdown">
                            <li>
                                <div class="row">
                                    <div class="col-lg-4 menu_padding">
                                        <ul>
                                            <li><a href="<?php echo e(url('services/'.$catagory ='vehicle')); ?>">  Vehicle</a></li>
                                            <li><a href="<?php echo e(url('services/'.$catagory ='light & sound')); ?>"> Light & Sound</a>
                                            </li>
                                            <li><a href="<?php echo e(url('services/'.$catagory ='holud snacks')); ?>"> Holud
                                                    Snacks</a></li>
                                            <li><a href="<?php echo e(url('services/'.$catagory ='dala kula')); ?>"> Dala Kula</a></li>
                                            
                                            <li><a href="<?php echo e(url('services/'.$catagory ='holud')); ?>">  Holud
                                                    Accessories</a>
                                            </li>
                                            <li><a href="<?php echo e(url('services/'.$catagory ='wedding')); ?>"> Wedding
                                                    Accessories</a>
                                            </li>
                                        </ul>
                                    </div>
                                    


                                    <div class="vl"></div>


                                    <div class="col-lg-4">

                                        <ul>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='venue')); ?>"> Venue</a></li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='catering')); ?>"> Catering</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('vendors/'.$catagory ='photography and cinematography')); ?>"> photography</a>
                                            </li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='decoration')); ?>">
                                                    Decoration</a>
                                            </li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='invitation cards')); ?>">
                                                    Invitation
                                                    Cards</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-3 menu_padding_3">
                                        <ul>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='dj')); ?>"> DJ</a></li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='makeup artist')); ?>"> Makeup
                                                    Artist</a>
                                            </li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='bakeries')); ?>"> Bakeries</a>
                                            </li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='mehedi')); ?>"> Mehedi</a></li>
                                            <li><a href="<?php echo e(url('vendors/'.$catagory ='kazi')); ?>"> Kazi</a></li>
                                        </ul>
                                    </div>

                                </div>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('event-coordinator')); ?>">Event Coordinator</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="https://ayojok.com/ideas-and-stories/" target="_blank">Ideas and
                            Stories</a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                        
                        <li class="nav-item dropdown loggeduser mr-5">
                            <a class="nav-link dropdown-toggle disabled" id="navbarDropdown"
                               href="<?php echo e(url('my-account')); ?>" data-toggle="dropdown" aria-haspopup="true"
                               aria-expanded="false">
                                <small>Hello,</small>
                                <?php if(is_null(Auth::user()->fname)): ?>
                                    <?php echo e(Auth::user()->name); ?>

                                <?php else: ?>
                                    <?php echo e(Auth::user()->fname); ?>

                                <?php endif; ?>
                            </a>
                            <ul class="megamenu dropdown-menu scrollable-menu" id="dropdown-menu"
                                aria-labelledby="navbarDropdown">
                                <li>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <ul>
                                                
                                                <li><a href="<?php echo e(route('wishlist.index')); ?>">My Wishlist</a></li>
                                                <li><a href="<?php echo e(route('myvendors', Auth::user()->id)); ?>">My Vendors</a>
                                                </li>
                                                <li><a href="<?php echo e(route('mychecklist',Auth::user()->id)); ?>">My Checklist</a>
                                                </li>
                                                <li><a href="<?php echo e(route('mybudget')); ?>">My Budget</a></li>
                                                <li><a title="Personal information"
                                                       href="<?php echo e(route('personal-info.edit', Auth::user()->id )); ?>">Personal
                                                        Information</a></li>

                                            </ul>
                                        </div>
                                        <div class="vl"></div>
                                        <div class="col-sm-6">
                                            <ul>
                                                
                                                <li><a href="<?php echo e(route('User.Message')); ?>">My inbox (<span id="inboxmess"><?php echo $__env->make('extra.mess', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></span>)</a></li>
                                                <li><a href="<?php echo e(route('confirm-query')); ?>">My queries (<span id="query_cart"><?php echo $__env->make('extra.cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></span>)</a></li>
                                                <li><a href="<?php echo e(route('client-orderlist', Auth::user()->id)); ?>">Order
                                                        List</a>
                                                <li><a href="<?php echo e(route('payment')); ?>">Payment</a></li>
                                                <li class="nav-item" data-toggle="tooltip" data-placement="bottom"
                                                    title="Logout">
                                                    <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                                       onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                          style="display: none;">
                                                        <?php echo e(csrf_field()); ?>

                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item" data-toggle="tooltip" data-placement="bottom" title="Confirmed Query ">
                            <a class="counter nav-link" href="<?php echo e(route('confirm-query')); ?>">
                                <i class="fa fa-bell" aria-hidden="true"></i><span class="badge badge-light" id="cartCount"><?php echo $__env->make('extra.query_cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></span>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" data-toggle="modal" href="#myModal">Login/Registration</a></li>
                        <?php endif; ?>
                    <?php endif; ?>



                    


                    
                    

                </ul>
                <!-- /End Top menu updated -->
            </div>
        </div>
    </nav>
</div>


<?php echo $__env->yieldContent('content'); ?>


        <!-- Footer -->
<footer class="footer"
        style="background-image: url(<?php echo e(asset('img/backgrounds/bg-footer_new.png')); ?>);background-size: auto;">
    <div class="container footer_padding">
        <!-- Row Contact -->
        <div class="row text-center">
            <div class="col-lg-1"></div>
            <div class=" col-lg-3 footer-contact-details">
                <h4> Call</h4>

                <p>+880-1959 555 666</p>
            </div>
            <div class="col-lg-4 footer-contact-details">
                <h4> Visit</h4>

                <p> H 52/1,Floor 5,Rd 3/A,Dhanmondi
                    <br>Dhaka - 1209 Bangladesh
                </p>
            </div>
            <div class="col-lg-3 footer-contact-details">
                <h4> Email</h4>

                <p>
                    <a href="mailto:info@ayojok.com">info@ayojok.com</a>
                </p>
            </div>
        </div>


        
        <div class="row">
            <div class="col-lg-12 text-center">
                <a href="<?php echo e(route('partners')); ?>"><p class="footer_text_3">Enlist with us, and become our valued partner.
                        Learn more.</p></a>
            </div>
        </div>
        


        <!-- Row Social and Menu -->
        <div class="row">
            <!-- Footer Menu -->
            <div class="col-lg-8 mb-4 mt-2" style="display: inherit;">
        <span class="footer-menu">
          <a href="<?php echo e(url('about-us')); ?>">About Us</a>
        </span>
        <span class="footer-menu">
          <a href="<?php echo e(url('terms-condition')); ?>">Terms and Condition</a>
        </span>
        <span class="footer-menu">
          <a href="<?php echo e(url('privacy')); ?>">Privacy Policy</a>
        </span>
                
            </div>
            <!-- Footer Social -->

            <div class="col-lg-4 " style="display:inline; padding:0px;text-align:center">



        <span>
          <a href="https://www.facebook.com/ayojokevents" target="_blank">
              <img class="img-fluid img-responsive social" src="<?php echo e(asset('img/social/facebook.png')); ?>" alt="">
          </a>
        </span>

        <span>
          <a href="https://www.instagram.com/ayojokevents/" target="_blank">
              <img class="img-fluid img-responsive social" src="<?php echo e(asset('img/social/instagram.png')); ?>" alt="">

          </a>
        </span>

        <span>
          <a href="https://www.youtube.com/channel/UC2Dn5jQAF8TV3_hPAoESk-Q" target="_blank">
              <img class="img-fluid img-responsive social" src="<?php echo e(asset('img/social/youtube.png')); ?>" alt="">
          </a>
        </span>

            </div>
        </div>


        <!-- Footer Copyright -->
        <div class="row">
            <div class="col-lg-12 text-center">
                <p class="copyright">Copyright <?php echo date("Y") ?> Ayojok</p>
            </div>
        </div>
    </div>
</footer>

<!-- Footer End-->


<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- Plugin JavaScript -->
<script src="<?php echo e(asset('vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/vide/jquery.vide.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/wowjs/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datetimepicker/js/bootstrap-datetimepicker.js')); ?>"></script>


<!-- Contact form JavaScript -->
<script src="<?php echo e(asset('js/contact_me.js')); ?>"></script>
<script src="<?php echo e(asset('js/jqBootstrapValidation.js')); ?>"></script>

<!-- Custom scripts for this theme -->
<script src="<?php echo e(asset('js/vitality.js')); ?>"></script>

<script type="text/javascript">
    $(".dropdown").hover(
            function () {
                $('.dropdown-menu', this).stop().fadeIn("fast");
            },
            function () {
                $('.dropdown-menu', this).stop().fadeOut("fast");
            });

    $('.modal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        button.one('focus', function (event) {
            $(this).blur();
        });
    });

    // $('.dropdown-toggle').click(function() {
    //     var location = $(this).attr('href');
    //     window.location.href = location;
    //     return false;
    // });
    jQuery('#levnumber').click(function (e) {
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        jQuery.ajax({
            url: "<?php echo e(url('/save-phn')); ?>",
            method: 'post',
            data: {
                number: jQuery('#num').val(),
            },
            success: function (result) {
                // $("#levnum .close").click();
                $("#levnum").modal('hide');
                $("#thanks").modal('show');
            }
        });
    });

</script>
<!-- Load Facebook SDK for JavaScript -->

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
