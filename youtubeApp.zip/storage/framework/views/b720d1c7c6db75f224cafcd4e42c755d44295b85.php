<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Confirmed Details
            </h1>
        </section>

        <section class="maincontent">

            <div class="col-md-6" style="margin-top:2rem;">

                <div class="box box-danger">
                    <div class="box-body">
                        <div class="details">

                            <label for="id" class="control-label col-md-4">Client ID:</label>

                            <div class="col-md-8">
                                <p><?php echo e($datas[0]->user->id); ?></p>
                            </div>
                            <label for="email" class="control-label col-md-4">Client Email:</label>

                            <div class="col-md-8">
                                <p><?php echo e($datas[0]->user->email); ?></p>
                            </div>
                            <label for="username" class="control-label col-md-4">Client Username:</label>

                            <div class="col-md-8">
                                <p><?php echo e($datas[0]->user->name); ?></p>
                            </div>
                            <label for="name" class="control-label col-md-4">Client Name:</label>

                            <div class="col-md-8">
                                <?php if(isset($datas[0]->user->fname) ): ?>
                                    <?php
                                    $name = "";
                                    $name = $name.$datas[0]->user->fname
                                    ?>
                                    <?php if(isset($datas[0]->user->lname)): ?>
                                        <?php

                                            $name = "";
                                            $name = $name.$datas[0]->user->fname.$datas[0]->user->lname;
                                        ?>
                                    <?php endif; ?>
                                    
                                    <p> <?php echo e($name); ?></p>
                                <?php else: ?>
                                    <p>Not Set Yet</p>
                                <?php endif; ?>
                            </div>
                            <label for="contact" class="control-label col-md-4">Client Contact:</label>

                            <div class="col-md-8">
                                <p><?php echo e($datas[0]->user->contact); ?></p>
                            </div>

                        </div>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

            </div>

            
            <div class="col-md-12" style="margin-top:2rem;">
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Vendor Confirm List</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive">
                        <table id="vendor" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Catagory</th>
                                <th>Vendor Name</th>
                                <th>Event Date</th>
                                <th>Time</th>
                                <th>Message</th>
                                <th>Advance</th>
                                <th>Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ven): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ven->vendor->id); ?></td>
                                    <td style="text-transform:uppercase;"><?php echo e($ven->catagory->name); ?></td>
                                    <td><?php echo e($ven->vendor->title); ?></td>
                                    <?php
                                    $dates = explode(',',$ven->order_date);
                                    ?>
                                    <td>
                                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $thedate = date("d-m-Y", strtotime($date));
                                            ?>
                                            <span><?php echo $thedate. '<br/>'; ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($ven->time); ?></td>
                                    <td><?php echo e(isset($ven->mess) ? $ven->mess : ""); ?></td>
                                    <td><?php echo e($ven->advance); ?></td>
                                    <td><?php echo e($ven->total); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

            </div>
            

            
            <div class="col-md-12" style="margin-top:2rem;">

                <div class="box box-info ">
                    <div class="box-header">
                        <h3 class="box-title">Service Confirm List</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive">
                        <table id="service" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Catagory</th>
                                <th>Service Name</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Message</th>
                                <th>Advance</th>
                                <th>Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pro->id); ?></td>
                                    <td style="text-transform:uppercase;"><?php echo e($pro->catagory->name); ?></td>
                                    <td><?php echo e($pro->product->title); ?></td>
                                    <?php
                                    $dates = explode(',',$pro->order_date);
                                    ?>
                                    <td>
                                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $thedate = date("d-m-Y", strtotime($date));
                                            ?>
                                            <span><?php echo $thedate. '<br/>'; ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($pro->time); ?></td>
                                    <td><?php echo e($pro->mess); ?></td>
                                    <td><?php echo e($pro->advance); ?></td>
                                    <td><?php echo e($pro->total); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            


        </section>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('#vendor,#service').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': false
        })
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>