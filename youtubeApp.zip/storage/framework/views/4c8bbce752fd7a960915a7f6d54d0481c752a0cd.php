<?php
/**
 * Created by PhpStorm.
 * User: Sohel Rana
 * Date: 3/12/2019
 * Time: 6:04 AM
 */
?>


<?php $__env->startPush('css'); ?>
<style>
    img {
        width: 300px;
        height: 200px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Add New Category
            </h1>
        </section>

        <section class="maincontent">

            <div class="col-md-12" style="margin-top:2rem;">

                <div class="box box-primary">
                    <div class="box-body" style="margin-top:2rem;">
                        <?php if(!isset($vdo_category)): ?>
                            <form action="<?php echo e(route('addCategorySubmit')); ?>" method="post" class="form-horizontal"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="row form-group">
                                    <div class="col-sm-2">
                                        <label for="vendor_name" class="control-label">Category Title: <span
                                                    style="color:red;">*</span> </label>
                                    </div>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="vendor_name" placeholder="Enter Title"
                                               name="vendor_title" required >
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <div class="control-label col-sm-2">
                                        <label class="" for="profile_image">Category Image:</label>

                                        <p>Max (600x600)</p>
                                    </div>
                                    <div class="col-sm-4">
                                        <input type="file" name="profile_image" id="profile_image" accept="image/*"
                                               class="form-control">
                                    </div>
                                    <div class="col-sm-6">
                                        <label for="profile_image">Profile Image Preview</label>

                                        <div id="profile-preview"></div>
                                    </div>
                                </div>


                                <div>
                                    <button class="btn btn-primary pull-right" type="submit">Upload Category</button>
                                </div>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(route('editVideoCategorySubmit',$vdo_category->id)); ?>" method="post" class="form-horizontal"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="row form-group">
                                    <div class="col-sm-2">
                                        <label for="vendor_name" class="control-label">Category Title: <span
                                                    style="color:red;">*</span> </label>
                                    </div>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="vendor_name" placeholder="Enter Title"
                                               name="vendor_title" required value="<?php echo e($vdo_category->title); ?>">
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <div class="control-label col-sm-2">
                                        <label class="" for="profile_image">Category Image:</label>

                                        <p>Max (600x600)</p>
                                    </div>
                                    <div class="col-sm-4">
                                        <input type="file" name="profile_image" id="profile_image" accept="image/*"
                                               class="form-control">
                                    </div>
                                    <div class="col-sm-6">
                                        <label for="profile_image">Profile Image Preview</label>

                                        <div id="profile-preview"></div>
                                        <img src="<?php echo e(asset($vdo_category->image)); ?>" id="previous_image">
                                    </div>
                                </div>


                                <div>
                                    <button class="btn btn-success pull-right" type="submit">Update Category</button>
                                </div>
                            </form>

                        <?php endif; ?>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

            </div>


        </section>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('#table').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': false,

        })
    })
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    function previewprofileImage() {
        var $preview = $('#profile-preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)) {
                return alert(file.name + " is not an image");
            }
            var reader = new FileReader();

            $(reader).on("load", function () {
                $preview.append($("<img/>", {src: this.result}));
            });

            reader.readAsDataURL(file);

            $('#previous_image').hide();

        }
    }


    $('#profile_image').on("change", previewprofileImage);


    $('#menu_type_select,#event_type_select,#speciality_select,#bakery_speciality_select,#venue_area_select,#home_service_select').select2();


</script>


<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>