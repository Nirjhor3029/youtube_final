<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Order List
            </h1>
        </section>

        <section class="maincontent">

            <div class="col-md-12" style="margin-top:2rem;">

                <div class="box box-danger">
                    <div class="box-body table-responsive">
                        <table id="table" class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Name</th>
                                <th>Ph No</th>
                                <th>Email</th>
                                <th>Order Dates</th>
                                
                                
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $check = 0;
                                $userdata = App\User::where('id',$data->user_id)->get();
                                $check =
                                App\Models\order::where('user_id',$data->user_id)->where('is_open',0)->count();
                                if ($check > 0) {
                                $color = 'background-color:rgb(255,255,255)';
                                }else{
                                $color = 'background-color:rgba(20,121,183,0.3)';
                                }
                                //dd($check);
                                ?>
                                <tr style="<?php echo e($color); ?>">
                                    <td>#00<?php echo e($data->id); ?><?php echo e($data->user_id); ?></td>
                                    <td><?php echo e($userdata[0]->name); ?> - (<?php echo e($userdata[0]->fname); ?><?php echo e($userdata[0]->lame); ?>)</td>
                                    <td><?php echo e($userdata[0]->contact); ?></td>
                                    <td><?php echo e($userdata[0]->email); ?></td>
                                    <td><?php echo e($data->created_at->format('d M Y')); ?></td>
                                    
                                    
                                    <td>
                                        <center>

                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <a href="<?php echo e(url('/admin/order/'.$userid = $data->user_id)); ?>"
                                                       class="btn btn-primary">
                                                        <span class="glyphicon glyphicon-eye-open"
                                                              aria-hidden="true"></span>
                                                    </a>
                                                </div>
                                                <div class="col-sm-6">
                                                    <?php if($check > 0): ?>
                                                        <h5>unseen</h5>
                                                    <?php else: ?>
                                                        <h5>Seen</h5>
                                                    <?php endif; ?>
                                                </div>
                                            </div>


                                        </center>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

            </div>


        </section>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('#table').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': false,

        })
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>