<style>
    .hide {
        display: none;
    }
</style>

<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel" >
            <div class="pull-left image" style="">
                <img src="<?php echo e(asset('img/web/youtube.jpg')); ?>" class="img-circle mt-4" alt="User Image"
                     style="height: 40px;background-color: #000">
            </div>
            <div class="pull-left info">
                <p><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></p>

                <p><?php echo e(\Illuminate\Support\Facades\Auth::user()->job_title); ?></p>
            </div>
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>
            <li>
                <a href="<?php echo e(route('adminhome')); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>


            <li class="treeview">
                <a href="#">
                    <span class="glyphicon glyphicon-gift"></span>
                    <span>User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?php echo e(route('userList')); ?>">
                            <i class="fa fa-dashboard"></i> <span>User List</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('userList')); ?>">
                            <i class="fa fa-dashboard"></i> <span>User Log</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('appUsersToken')); ?>">
                            <i class="fa fa-dashboard"></i> <span>App User Tokens</span>
                        </a>
                    </li>
                </ul>
            </li>



            
            <li class="treeview">
                <a href="#">
                    <span class="glyphicon glyphicon-knight"></span>
                    <span>Video Details</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="<?php echo e(route('videoCategories')); ?>">
                            <i class="fa fa-dashboard"></i> <span>Video Categories</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('showVideoSubCategories')); ?>">
                            <i class="fa fa-dashboard"></i> <span>Video Sub Categories</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('showTags')); ?>">
                            <i class="fa fa-dashboard"></i> <span>Video Tags</span>
                        </a>
                    </li>
                </ul>
            </li>











            <li>
                <a href="<?php echo e(route('videos')); ?>">
                    <i class="fa fa-dashboard"></i> <span>Video List</span>
                </a>
            </li>









        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
