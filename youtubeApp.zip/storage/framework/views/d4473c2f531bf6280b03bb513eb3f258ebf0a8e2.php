<?php
/**
 * Created by PhpStorm.
 * User: Sohel Rana
 * Date: 3/17/2019
 * Time: 12:25 AM
 */

?>





<?php $__env->startPush('css'); ?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>

    img{
        width: 100px;
        height: 100px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">



        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Videos
            </h1>
        </section>

        <section class="maincontent">
            <div class="col-md-12" style="margin-top:2rem;">

                <div class="box box-danger">

                    <div class="box-body table-responsive">
                        <table id="table" class="table table-bordered">
                            <a href="<?php echo e(route('addVideo')); ?>" class="btn btn-primary">Add New Video</a>
                            <thead>
                            <tr>
                                <th> ID</th>
                                <th>Video Id</th>
                                <th>Category</th>
                                <th>Sub Category</th>
                                <th>Tags</th>
                                <th>Video Url</th>
                                <th>Video Author Url</th>
                                <th>Video Author Name</th>
                                <th>Title</th>
                                <th>description</th>
                                <th>Thumbnail Url</th>
                                <th>Video Length</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($video->id); ?></td>
                                    <td><?php echo e($video->video_id); ?></td>
                                    <td><?php echo e($video->category_id); ?></td>
                                    <td>
                                        <?php
                                            $tags = "";
                                            foreach($video->tags as $tag){
                                                $tags = $tags.",".$tag->title;
                                            }
                                        ?>
                                        <?php echo e($tags); ?>

                                    </td>
                                    <td><?php echo e($video->sub_category_id); ?></td>
                                    <td><?php echo e($video->video_url); ?></td>
                                    <td><?php echo e($video->video_author_url); ?></td>
                                    <td><?php echo e($video->video_author_name); ?></td>
                                    <td><?php echo e($video->title); ?></td>
                                    <td><?php echo e($video->description); ?></td>
                                    <td><?php echo e($video->thumbnail_url); ?></td>
                                    <td><?php echo e($video->video_length); ?></td>

                                    <td>
                                        
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <a href="<?php echo e(route('deleteVideo',$video->id)); ?>"><i class="fa fa-remove" style="font-size:30px;color:red"></i></a>
                                            </div>
                                            <div class="col-sm-2">
                                                <a href="<?php echo e(route('editVideo',$video->id)); ?>"><i class="fa fa-edit" style="font-size:30px;color:green"></i></a>
                                            </div>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

            </div>

        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>