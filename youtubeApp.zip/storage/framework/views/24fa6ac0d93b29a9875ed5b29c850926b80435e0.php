<?php $__env->startSection('content'); ?>
        <!-- Masthead -->
<header class="masthead" style="background-image: url('img/backgrounds/Ayojok-UI-1_03.png');background-size: cover;">
  <!-- <div class="container h-100">
  <div class="row h-100">
  <div class="col-12 my-auto text-center text-white">
  <img class="masthead-img img-fluid mb-3" src="img/profile.png" alt="">
</div>
</div>
</div> -->
  <!--  -->
  <div>
    <div class="scroll-down">
      <div class="logos">
        <img class="logo" src="img/ayojok_v2.png">

        <p class="tagline" style="">Bangladesh's first & biggest event booking service</p>
      </div>
      <?php echo e(Form::open(['route'=>'find', 'method' => 'post'])); ?>

      <div style="text-align:center;" class="catagory input-group">
        <div class="col-lg-4 prefix">
          <span>I am looking for</span>
        </div>
        <div class="col-lg-7 search-cat">
          <select class="form-control" name="catagory">
            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($vendor->id); ?>"
                      style="text-transform: capitalize;"><?php echo e($vendor->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($service->id); ?>"
                      style="text-transform: capitalize;"><?php echo e($service->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="col-lg-1 findbtn">
          <?php echo e(Form::button('Go',['class'=>'btn btn-search','type'=>'submit'])); ?>

        </div>
      </div>
      <?php echo e(Form::close()); ?>

      <div class="mobile_view abc">
        <div class="col-lg-4">
          <i class="fa fa-check" aria-hidden="true"></i>
          <span class="header-write">Find services</span>
        </div>
        <div class="col-lg-4">
          <i class="fa fa-check" aria-hidden="true"></i>
          <span class="header-write">Fast and Easy</span>
        </div>
        <div class="col-lg-4">
          <i class="fa fa-check" aria-hidden="true"></i>
          <span class="header-write">Zero Hassle</span>
        </div>
      </div>
    </div>

  </div>
</header>

<!-- /End FB Profile Style -->
<section class=" bg-white">
  <div class="container-fluid">

    <div class="row row pt-2 pb-3">

      <div class="col-lg-12 text-center">
        <div class="fb-profile-text" style="text-align:center;">
          <p class="fb-profile-text1">Ayojok brings wide selection of trusted event service providers for your
            desire budget and occasion.<br>
            Save time & money as you browse all kinds of event related services anywhere, anytime.</p>

          <p class="tag1">How it works? Simple, easy <span class="andSymbl">&</span> fast!</p>

          <div class="row scroll-down" style="text-allign:center;">
            <div class="col-lg-4">
              <div class="content_ico">

                <a href="https://www.ayojok.com/how-it-works">
                  <img class="icon1" src="<?php echo e(asset('img/icons/mouse.png')); ?>">
                  <span class="how_it_works_icon">Choose services</span>
                </a>

              </div>

            </div>

            <div class="col-lg-4">

              <div class="content_ico2">
                <a href="https://www.ayojok.com/how-it-works">

                  <img class="icon" src="<?php echo e(asset('img/icons/phone.png')); ?>">
                  <span class="how_it_works_icon">Get notified about availability</span>
                </a>

              </div>
            </div>
            <div class="col-lg-4">

              <div class="content_ico3">
                <a href="https://www.ayojok.com/how-it-works">

                  <img class="icon" src="<?php echo e(asset('img/icons/calender_v2.png')); ?>">
                  <span class="how_it_works_icon">Confirm!</span>
                </a>

              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- /End FB Profile Style -->

<!-- Values Section -->


<!-- Our Service -->
<section class="page-section pricing">
  <div class="container wow fadeIn mb-4">
    <div class="text-center wow fadeIn">
      <p style="color:black; font-size:26px;">Find services at every budget</p>

      <p style="color:black; font-size:18px;">Venues, catering, decoration, photographers & more</p>
    </div>
    <div class="row text-center justify-content-md-center">
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='venue')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Venue</h4>
              <img src="<?php echo e(asset('img/final/Venue.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>

        </div>

      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='catering')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Catering</h4>
              <img src="<?php echo e(asset('img/final/catering.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
          <a href="<?php echo e(url('vendors/'.$catagory ='photography & cinematography')); ?>"></a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='photography and cinematography')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Photography</h4>
              <img src="<?php echo e(asset('img/final/Photography.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='decoration')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Decoration</h4>
              <img src="<?php echo e(asset('img/final/Decoration.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
    </div>

    <!-- Sub Service Start-->
    <div class="row text-center mt-4">
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='invitation cards')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Invitation Cards</h4>
              <img src="<?php echo e(asset('img/final/invitation card.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='dj')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">DJ</h4>
              <img src="<?php echo e(asset('img/final/DJ.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='makeup artist')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Makeup Artist</h4>
              <img src="<?php echo e(asset('img/final/Make UP.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='bakeries')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Bakeries</h4>
              <img src="<?php echo e(asset('img/final/Bakeries.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
    </div>

    <div class="row text-center mt-4">
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='mehedi')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Mehedi</h4>
              <img src="<?php echo e(asset('img/final/Mehedi.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('vendors/'.$catagory ='kazi')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Kazi</h4>
              <img src="<?php echo e(asset('img/final/Kazi.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>


      
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('services/'.$catagory ='vehicle')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Vehicle</h4>
              <img src="<?php echo e(asset('img/final/Vehicle.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>

      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('services/'.$catagory ='light & sound')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">light & sound</h4>
              <img src="<?php echo e(asset('img/final/Lighting.jpg')); ?>"
                   class="img-fluid mx-auto zoom " alt="">
            </div>
          </a>
        </div>
      </div>

    </div>



    <div class="row text-center justify-content-md-center mt-4" id="hidden_row" style="display: none">
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('services/'.$catagory ='holud snacks')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Holud & Snacks</h4>
              <img src="<?php echo e(asset('img/final/Holud Snacks.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>

        </div>

      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('services/'.$catagory ='dala kula')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Dala Kula</h4>
              <img src="<?php echo e(asset('img/final/Dala-Kula.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>

      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('services/'.$catagory ='holud')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Holud Accessories</h4>
              <img src="<?php echo e(asset('img/final/Holud Accessories.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
      <div class="col-xs-6 col-lg-3">
        <div class="item">

          <a href="<?php echo e(url('services/'.$catagory ='wedding')); ?>">

            <div class="img-wrapper">
              <h4 class="fontOverImage">Wedding Accessories</h4>
              <img src="<?php echo e(asset('img/final/Wedding Accessories.jpg')); ?>"
                   class="img-fluid mx-auto zoom" alt="">
            </div>
          </a>
        </div>
      </div>
    </div>


    <!-- ./Sub Service Ends-->
    
            <center><a href="javascript:void(0);" class="btn btn-danger rounded btn-sm custom-btn" style="color: white;padding: 1% 5%;text-transform: none;background-color: #810d28" onclick="makeDisplayBlock()" id="btn_loadMore">Load more</a></center>


  </div>

</section>

<!-- Event Section -->
<!-- <section class="page-section bg-light">
    <div class="container text-center wow fadeIn mt-4 mb-4">
      <div class="row mt-4">
        <div class="col-lg-3 wow fadeIn event-sec" data-wow-delay=".2s">
          <a href="<?php echo e(url('event-coordinator')); ?>">
            <div class="hovereffect" style="cursor: pointer;">
              <img class="img-responsive" src="img/service1.jpg" alt="">

              <div class="overlay">
                <h2>Checking</h2>
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-3 wow fadeIn" data-wow-delay=".2s">
          <a href="<?php echo e(url('event-coordinator')); ?>">
            <div class="hovereffect" style="cursor: pointer;">
              <img class="img-responsive" src="img/service2.jpg" alt="">
              <div class="overlay">
                <h2>Monitoring</h2>
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-3 mb-3 wow fadeIn" data-wow-delay=".2s">

          <div class="event-dec">
            <div style="text-align:center;">
              <h2>Event </h2><h3>Coordinator</h3>
            </div>
            <ul class="servicelist list-group">
              <li class="list-group">Checking</li>
              <li class="list-group">Monitoring</li>
              <li class="list-group">Assuring</li>
            </ul>
          </div>

          <a href="<?php echo e(url('event-coordinator')); ?>" class="btn btn-proceed mt-5">Learn More</a>

        </div>
        <div class="col-lg-3 wow fadeIn" data-wow-delay=".2s" >
          <a href="<?php echo e(url('event-coordinator')); ?>">
            <div class="hovereffect" style="cursor: pointer;">
              <img class="img-responsive" src="img/service3.jpg" alt="">
              <div class="overlay">
                <h2>Assuring</h2>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
  </section> -->

<!-- Hours Section - Repurposed from Pricing Table -->
<!-- <section class="page-section pricing" id="hours" style="background-image: url('img/backgrounds/bg-pricing.jpg')">
  <div class="container wow fadeIn mt-4 mb-4">
    <div class="text-center">
      <h2>Planning Tools</h2>
      <hr class="colored">
      <p>Plan your wedding the right way with our effective planning tools</p>
    </div>
    <div class="row"> -->
<!-- Pricing Table 1 -->
<!-- <div class="col-md-4">
          <div class="pricing-item">
            <?php if(Auth::check()): ?>
        <a href="<?php echo e(route('mychecklist',Auth::user()->id)); ?>">
              <img src="img/planning-tools/my-checklist.png" style="width:25%;margin:3em;" alt="">
              <h4 class="mb-5">My Checklist</h4>
            </a>
            <?php else: ?>
        <a href="#myModal" data-toggle="modal">
          <img src="img/planning-tools/my-checklist.png" style="width:25%;margin:3em;" alt="">
          <h4 class="mb-5">My Checklist</h4>
        </a>
        <?php endif; ?>

        </div>
      </div> -->
<!-- Pricing Table 2 -->
<!-- <div class="col-md-4">
          <div class="pricing-item">
            <?php if(Auth::check()): ?>
        <a href="<?php echo e(route('myvendors', Auth::user()->id)); ?>">
              <img src="img/planning-tools/my-vendor.png" style="width:25%;margin:3em;" alt="">
              <h4 class="mb-5">My Vendors</h4>
            </a>
            <?php else: ?>
        <a href="#myModal" data-toggle="modal">
          <img src="img/planning-tools/my-vendor.png" style="width:25%;margin:3em;" alt="">
          <h4 class="mb-5">My Vendors</h4>
        </a>
        <?php endif; ?>
        </div>
      </div> -->
<!-- Pricing Table 3 -->
<!-- <div class="col-md-4">
          <div class="pricing-item">
            <?php if(Auth::check()): ?>
        <a href="<?php echo e(route('mybudget')); ?>">
              <img src="img/planning-tools/budget-manager.png" style="width:25%;margin:3em;" alt="">
              <h4 class="mb-5">Budget Manager</h4>
            </a>
            <?php else: ?>
        <a href="#myModal" data-toggle="modal">
          <img src="img/planning-tools/budget-manager.png" style="width:25%;margin:3em;" alt="">
          <h4 class="mb-5">Budget Manager</h4>
        </a>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section> -->
<!-- plaaning tools new UI -->
<section class="page-section pricing" id="hours" style="background-color: white;color: #323232">


  <div class="container wow fadeIn mt-5 mb-5">

    <div class="row">


      <!-- Pricing Table 1 -->
      

      <div class="col-md-6">

        <div class="pricing-item_1 plan_tool_rectangle">
          

          <div class="pricing_content">
            <h4 style="" class="pricing_title"> Save time & money<br> and be stress free </h4>

            <p class="pricing_para" style="text-transform: none">Our Event Coordinator <br>
              gives you control <br>
              and supervision over <br>
              your events without<br>
              hassle and stress. </p>
            <a href="#" class="btn btn-danger rounded btn-sm custom-btn"
               style="color: white;padding: 1% 5%;text-transform: none;background-color: #810D28">Learn
              more</a>
          </div>
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="pricing-item_2 plan_tool_rectangle pricing_item_2">
          

          <div class="pricing_content">
            <h4 style="" class="pricing_title"> Easy Planning<br> with easy tools </h4>

            <p class="pricing_para" style="text-transform: none">Plan your wedding the right way  <br>
              with our effective free planning tools. <br>
              Manage checklists, vendors,<br>
              budgets and more.<br>
            </p>

            

            <div class="row planning_tools_icons center-block" style="">

              


              <?php if(Auth::check()): ?>
                <div class="col-sm-4 planning_tools_icon">
                  <a href="<?php echo e(route('mychecklist',Auth::user()->id)); ?>">
                    <img class="icon2" src="<?php echo e(asset('img/planning-tools/my-checklist.png')); ?>">

                    <p class="mt-3">My <br> Checklist</p>
                  </a>
                </div>
              <?php else: ?>
                <div class="col-sm-4 planning_tools_icon">
                  <a href="#myModal" data-toggle="modal">
                    <img class="icon2" src="<?php echo e(asset('img/planning-tools/my-checklist.png')); ?>">

                    <p class="mt-3">My <br> Checklist</p>
                  </a>
                </div>

              <?php endif; ?>

              <?php if(Auth::check()): ?>
                <div class="col-sm-4 planning_tools_icon">
                  <a href="<?php echo e(route('myvendors', Auth::user()->id)); ?>">
                    <img class="icon2" src="<?php echo e(asset('img/planning-tools/my-vendor.png')); ?>">

                    <p class="mt-3">My <br> Vendors</p>
                  </a>
                </div>
              <?php else: ?>
                <div class="col-sm-4 planning_tools_icon">
                  <a href="#myModal" data-toggle="modal">
                    <img class="icon2" src="<?php echo e(asset('img/planning-tools/my-vendor.png')); ?>">

                    <p class="mt-3">My <br> Vendors</p>
                  </a>
                </div>
              <?php endif; ?>

              <?php if(Auth::check()): ?>
                <div class="col-sm-4 planning_tools_icon">
                  <a href="<?php echo e(route('mybudget')); ?>">
                    <img class="icon2" src="<?php echo e(asset('img/planning-tools/budget-manager.png')); ?>">

                    <p class="mt-3">My <br> Budget</p>

                  </a>
                </div>
              <?php else: ?>
                <div class="col-sm-4 planning_tools_icon">
                  <a href="#myModal" data-toggle="modal">
                    <img class="icon2" src="<?php echo e(asset('img/planning-tools/budget-manager.png')); ?>">

                    <p class="mt-3">My <br> Budget </p>
                  </a>
                </div>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
    </div>

    
  </div>

</section>
<!--End of new planning tools  -->
<!-- Menu Gallery -->
<section class="page-section" id="menu">
  <div class="container wow fadeIn  mb-4">
    <div class="text-center">
      <p class="" style="">
        <span style="transform: scale(2, 1.3);font-size: 25px;font-weight: 200;font-family: 'Source Sans Pro', sans-serif;">Ideas and stories</span>
        <br>
        Get your creative inspiration from current trend and tips.</p>
    </div>

    <div class="portfolio-gallery">
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">

          <div class="image">
            <a href="<?php echo e($item->get_link()); ?>" title="<?php echo e($item->get_title()); ?>">


              
            </a>

          </div>
          <p style="width:100%;" class="text-center txt"><?php echo e($item->get_title()); ?></p>


        </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>

  </div>
</section>


<script>
  function makeDisplayBlock() {
    document.getElementById('hidden_row').style.display = "flex";

    $('#btn_loadMore').hide();
  }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>