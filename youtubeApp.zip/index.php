<?php
    header('location:public');
?>